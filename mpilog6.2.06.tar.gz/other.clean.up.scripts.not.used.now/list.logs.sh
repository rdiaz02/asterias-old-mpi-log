#!/bin/sh
ls -gG MPIerrorlog
ls -gG MPI_killed_procs*
ls -gG adhocMPIErrorLog*
