#!/bin/sh
ls -gGrt MPIerrorlog
ls -gGrt MPI_killed_procs*
ls -gGrt adhocMPIErrorLog*
