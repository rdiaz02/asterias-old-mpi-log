library(Rmpi)

## sometimes can get lam autostarted,
## with a single node. That is an error.
## make sure chekRmpi catches it.
if(mpi.universe.size() < 50) { 
   system("sleep 200")
   }
mpi.spawn.Rslaves(nslaves = mpi.universe.size())
mpi.close.Rslaves()
mpi.quit()
q()


###  This is code to be used from the function checkRmpi.py,
###  which acts like a daemon, checking that Rmpi can get
###  started.
