#!/usr/bin/python

## Like chekRmpi.py, but:
    ## called only once (no eternal loop)
    ## writes to a file : adhoceMPIErrorLog.Nombredelnodo

## This script tests that Rmpi can be started successfully.
## This script lives in /http
## The output is in /http/mpi.log/MPIErrorLog

import os
import time
import socket
import signal
import sys

if len(sys.argv) > 1:
    application = sys.argv[1]
else:
    application = 'NULL'

clusterNodes = range(2, 23) + [27, 28, 30]

def collectZombies(k = 10):
    """ Make sure there are no zombies in the process tables.
    This is probably an overkill, but works.
    """
    for nk in range(k):
        try:
            tmp = os.waitpid(-1, os.WNOHANG)
        except:
            None

def checkMPI(hname):
    rcmdb = os.spawnlp(os.P_NOWAITO, '/usr/bin/R', '/usr/bin/R', 'CMD',
                       'BATCH', '-q', '/http/mpi.log/simple.test.R', '/dev/null')
    time.sleep(10) ## make sure R has enough time to complete
    Rpid = os.popen('ps --ppid ' + str(rcmdb) + ' -o "%p" --no-headers').readline()
    os.waitpid(-1, os.WNOHANG) ## if BATCH finished OK, get the zomby

    if len(sys.argv) > 1:
        MPIerrorlog = open('/http/mpi.log/adhocMPIErrorLog.' + application + '.' + socket.gethostname(), mode = 'a')
    else:
        MPIerrorlog = open('/http/mpi.log/adhocMPIErrorLog.' + socket.gethostname(), mode = 'a')

    if len(Rpid):
        try:
	    os.kill(int(rcmdb), signal.SIGKILL)
	except:
	    None
	try:
	    os.kill(int(Rpid), signal.SIGKILL)
	except:
	    None
        time.sleep(1) ## need to wait a little, o.w. the killing of rcmdb seems not to
        ## have been completed
        collectZombies(5)
 
	MPIerrorlog.write('MPI fails at ' + 
	time.ctime(time.time()) + '. --- Found at ' +
	hname + '\n')

    	kk = os.system('lamhalt >&/dev/null; lamwipe >&/dev/null; killall lamd >&/dev/null')
        
        os.system('lamboot >&/dev/null')

    ## Will get rid of the following later
##    else:
##	MPIerrorlog.write('       OK.   ' + hname + 
##	' at ' + time.ctime(time.time()) +'\n')
	
    os.system('rm -f localhost.*.log')
    os.system('rm -f .*.log')
    MPIerrorlog.close()

### end of function definition
    
    
if len(sys.argv) > 1:    
    if not os.path.exists('/http/mpi.log/adhocMPIErrorLog.' + application + '.' + socket.gethostname()):
        os.system('touch /http/mpi.log/adhocMPIErrorLog.' + application + '.' + socket.gethostname())
else:    
    if not os.path.exists('/http/mpi.log/adhocMPIErrorLog.' + socket.gethostname()):
        os.system('touch /http/mpi.log/adhocMPIErrorLog.' + socket.gethostname())

  
numlamd = os.popen('ps -C lamd -o "%U %p" | grep www-data | wc -l').readline()

if not len(numlamd):
    MPIerrorlog.write('MPI fails with NO LAMD at ' +
    time.ctime(time.time()) + '. --- Found at ' +
    hname + '\n')
elif int(numlamd) > 1:
    MPIerrorlog.write('MPI fails with MULTIPLE LAMS at ' +
    time.ctime(time.time()) + '. --- Found at ' +
    hname + '\n')
    
    for node in clusterNodes:
	try:
	    kk = os.system("ssh 192.168.2." + str(node) + 
	    " 'lamhalt >&/dev/null; lamwipe >&/dev/null; killall lamd >&/dev/null'")
	except:
	    None
	os.system('lamboot /var/www/lamb-host.def >&/dev/null')
	
checkMPI(socket.gethostname())
